package com.dbs.challenge;

import org.apache.commons.cli.*;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.logging.Logger;

public class DbsChallenge {

    private static Logger logger = Logger.getGlobal();

    public static void main(String[] args) {

        Options options = new Options();

        Option input = new Option("i", "input", true, "input file path");
        input.setRequired(true);
        options.addOption(input);

        Option output = new Option("o", "output", true, "output file");
        output.setRequired(true);
        options.addOption(output);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
            String inputFilePath = cmd.getOptionValue("input");
            String outputFilePath = cmd.getOptionValue("output");

            String dir = System.getProperty("user.dir");

            TreeMap<String, Node> nodes = readFile(dir + File.separator + inputFilePath);
            List<Node> sortedNodes = DbsChallengeHelper.sort(new ArrayList<>(nodes.values()));
            parseData(sortedNodes, nodes);
            output(nodes, dir + File.separator + outputFilePath);
        } catch (ParseException e) {
            logger.severe(e.getMessage());
            formatter.printHelp("java -jar spreasheet.jar", options);
            System.exit(1);
        } catch (DbsChallengeException e) {
            logger.severe(e.getMessage());
            System.exit(2);
        } catch (IOException e) {
            logger.severe(e.getMessage());
            System.exit(3);
        }
    }

    private static TreeMap<String, Node> readFile(String file) throws IOException {
        TreeMap<String, Node> nodes = new TreeMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String st;
            char row = 'A';
            while ((st = br.readLine()) != null) {
                DbsChallengeHelper.parseLine(st, row, nodes);
                row++;
            }
        }
        return nodes;
    }

    private static void parseData(List<Node> nodes, Map<String, Node> nodesMap) {
        for (Node node : nodes) {
            if (StringUtils.startsWith(node.getExpression(), "=")) {
                String ex = node.getExpression().substring(1);

                Map<String, BigDecimal> valueMap = new HashMap<>();
                String[] colValExs = StringUtils.split(node.getExpression().substring(1), DbsChallengeHelper.SUPPORTED_OPERATORS);

                for (String item : colValExs) {
                    if (Character.isLetter(item.charAt(0))) {
                        Node n = nodesMap.get(item);
                        valueMap.put(n.getLabel(), n.getValue());
                    }
                }

                BigDecimal val = DbsChallengeHelper.eval(ex, valueMap);
                node.setValue(val);
            }

        }
    }

    private static void output(TreeMap<String, Node> nodes, String file) throws IOException {
        char curr = nodes.firstKey().charAt(0);
        FileWriter fw = new FileWriter(file);
        try (BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(nodes.get(nodes.firstKey()).getValue().toString());
            for (Map.Entry<String, Node> entry : nodes.entrySet()) {
                if (StringUtils.equals(entry.getKey(), nodes.firstKey())) {
                    continue;
                }

                if (entry.getKey().charAt(0) != curr) {
                    bw.newLine();
                    bw.write(entry.getValue().getValue().toString());
                    curr = entry.getKey().charAt(0);
                } else {
                    bw.write(",");
                    bw.write(entry.getValue().getValue().toString());
                }
            }
        }
    }
}

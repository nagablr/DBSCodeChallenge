package com.dbs.challenge;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Node {
    private String label;
    private String expression;
    private List<Node> neighbors;
    private BigDecimal value;

    public Node(String label, String expression) {
        this.label = label;
        this.expression = expression;
        neighbors = new ArrayList<>();
    }

    public Node(String label) {
        this.label = label;
        neighbors = new ArrayList<>();
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<Node> getNeighbors() {
        return neighbors;
    }

    public void setNeighbors(List<Node> neighbors) {
        this.neighbors = neighbors;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }
}
